package com.example.ProductInventoryManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductInventoryManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
