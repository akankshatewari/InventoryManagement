package com.example.ProductInventoryManagement.Service;

import com.example.ProductInventoryManagement.Exceptions.custom.ResourceNotFoundException;
import com.example.ProductInventoryManagement.Model.Order;
import com.example.ProductInventoryManagement.dao.OrderRepository;
import com.example.ProductInventoryManagement.dto.OrderRequest;
import com.example.ProductInventoryManagement.dto.OrderResponse;
import com.example.ProductInventoryManagement.dto.ProductRequest;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class OrderServiceImpl implements OrderService{

    @Autowired
    ProductService productService;

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    OrderRepository orderRepository;

    @Override
    public Order createOrder(OrderRequest orderRequest, Long productId, Long buyerId) {

        Long product = productService.displayProductStock(productId);
        if(product >= orderRequest.getOrderQuantity()){
            log.info("product quantity greater than required Quantity {} ", product);
            Order order = modelMapper.map(orderRequest, Order.class);
            order.setBuyerId(buyerId);
            order.setProductId(productId);
            orderRepository.save(order);

            ProductRequest productRequest = new ProductRequest();
            productRequest.setProductId(productId);
            productRequest.setInStockQuantity(orderRequest.getOrderQuantity() * -1);
            productService.addOrUpdateProduct(productRequest);
        }else{
            throw new ResourceNotFoundException("Required Quantity Exceeds in stock for product Id "+ productId);
        }
        return null;
    }

    @Override
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }
}
