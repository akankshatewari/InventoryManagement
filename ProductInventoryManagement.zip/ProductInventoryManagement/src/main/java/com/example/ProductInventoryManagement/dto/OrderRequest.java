package com.example.ProductInventoryManagement.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderRequest {
    private Long orderQuantity;
}
