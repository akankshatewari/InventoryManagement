package com.example.ProductInventoryManagement.Service;

import com.example.ProductInventoryManagement.Exceptions.custom.ResourceNotFoundException;
import com.example.ProductInventoryManagement.Model.Product;
import com.example.ProductInventoryManagement.dao.ProductRepository;
import com.example.ProductInventoryManagement.dto.ProductRequest;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.Optional;

@Service
@Slf4j
public class ProductServiceImpl implements ProductService{

    @Autowired
    ProductRepository productRepository;

    @Autowired
    ModelMapper modelMapper;

    @Override
    public Product addOrUpdateProduct(ProductRequest productRequest) {
        Product existingProduct = productRepository.findById(productRequest.getProductId()).orElse(null);
        if (existingProduct != null) {
            existingProduct.setInStockQuantity(existingProduct.getInStockQuantity() + productRequest.getInStockQuantity());
            return productRepository.save(existingProduct);
        } else {
            Product productDetails = modelMapper.map(productRequest, Product.class);
            return productRepository.save(productDetails);
        }
    }

    @Override
    public Long displayProductStock(Long productId) {
        Optional<Product> product = productRepository.findById(productId);
        if(product.isPresent()) {
            return product.get().getInStockQuantity();
        }else{
            throw new ResourceNotFoundException("Product with id " + productId + " not found");
        }
    }
}
