package com.example.ProductInventoryManagement.Service;

import com.example.ProductInventoryManagement.Model.Buyer;
import com.example.ProductInventoryManagement.dto.BuyerRequest;

public interface BuyerService {
    Buyer onboardBuyer(BuyerRequest buyer);
}
