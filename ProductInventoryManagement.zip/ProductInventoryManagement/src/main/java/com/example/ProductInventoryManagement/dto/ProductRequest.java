package com.example.ProductInventoryManagement.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductRequest {
    private  Long productId;
    private String productName;
    private Long inStockQuantity;
}
