package com.example.ProductInventoryManagement.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderResponse {

    private Long orderId;
    private Long buyerId;
    private Long productId;
    private String buyerName;
    private String productName;
    private Long orderQuantity;

}
