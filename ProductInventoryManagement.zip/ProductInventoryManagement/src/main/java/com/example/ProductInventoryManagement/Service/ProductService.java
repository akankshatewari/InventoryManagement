package com.example.ProductInventoryManagement.Service;

import com.example.ProductInventoryManagement.Model.Product;
import com.example.ProductInventoryManagement.dto.ProductRequest;

import java.util.List;

public interface ProductService {
    Product addOrUpdateProduct(ProductRequest productRequest);

    Long displayProductStock(Long productId);
}
