package com.example.ProductInventoryManagement.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BuyerRequest {
    private String name;
    private Long phone;
}
