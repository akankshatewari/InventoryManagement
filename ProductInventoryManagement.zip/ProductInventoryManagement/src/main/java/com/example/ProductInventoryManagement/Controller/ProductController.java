package com.example.ProductInventoryManagement.Controller;

import com.example.ProductInventoryManagement.Model.Product;
import com.example.ProductInventoryManagement.Service.ProductService;
import com.example.ProductInventoryManagement.dto.ProductRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ProductController {

    @Autowired
    ProductService productService;

    @PutMapping("/api/v1/product")
    public ResponseEntity<Product> addProduct(@RequestBody ProductRequest productRequest) {

        Product product = productService.addOrUpdateProduct(productRequest);
        return new ResponseEntity<>(product, HttpStatus.CREATED);
    }

    @GetMapping("/api/v1/product/{productId}/stockInHand")
    public ResponseEntity<Long> getProductStockDetail(@PathVariable Long productId){

        Long productStock = productService.displayProductStock(productId);
        return new ResponseEntity<>(productStock, HttpStatus.CREATED);
    }


}
