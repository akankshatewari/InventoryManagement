package com.example.ProductInventoryManagement.Controller;

import com.example.ProductInventoryManagement.Model.Buyer;
import com.example.ProductInventoryManagement.Model.Order;
import com.example.ProductInventoryManagement.Service.OrderService;
import com.example.ProductInventoryManagement.dto.OrderRequest;
import com.example.ProductInventoryManagement.dto.OrderResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class OrderController {

    @Autowired
    OrderService orderService;

    @PostMapping("/api/v1/product/{productId}/buyer/{buyerId}/order")
    public ResponseEntity<Order> createOrder(@RequestBody OrderRequest orderRequest,
                                             @PathVariable Long productId,
                                             @PathVariable Long buyerId) {

        Order order = orderService.createOrder(orderRequest, productId, buyerId);

       return new ResponseEntity<>(order, HttpStatus.OK);
    }

    @GetMapping("/api/v1/product/order")
    public ResponseEntity<List<Order>> getAllOrders(){
        List<Order> allOrders = orderService.getAllOrders();
        return new ResponseEntity<>(allOrders, HttpStatus.OK);
    }
}
