package com.example.ProductInventoryManagement.Model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
public class Product {

    @Id
    private Long productId;
    private String productName;
    private Long inStockQuantity;
}
