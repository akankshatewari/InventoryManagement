package com.example.ProductInventoryManagement.Exceptions;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;


@Setter
@Getter
public class ErrorResponse {
    private HttpStatus status;
    private String message;
    private String details;

    public ErrorResponse(HttpStatus httpStatus, String message, String resourceNotFound) {
    }
}
