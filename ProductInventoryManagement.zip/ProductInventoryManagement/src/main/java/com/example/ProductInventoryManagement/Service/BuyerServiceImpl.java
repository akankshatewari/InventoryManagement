package com.example.ProductInventoryManagement.Service;

import com.example.ProductInventoryManagement.Model.Buyer;
import com.example.ProductInventoryManagement.dao.BuyerRepository;
import com.example.ProductInventoryManagement.dto.BuyerRequest;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
public class BuyerServiceImpl implements BuyerService{

    @Autowired
    BuyerRepository buyerRepository;

    @Autowired
    ModelMapper mapper;

    @Override
    public Buyer onboardBuyer(BuyerRequest buyer) {
        Optional<Buyer> buyerDetails = buyerRepository.findByPhone(buyer.getPhone());
        if(buyerDetails.isPresent()) {
            throw new RuntimeException("Buyer Already Exists");
        }
        return  buyerRepository.save(mapper.map(buyer, Buyer.class));
    }
}
