package com.example.ProductInventoryManagement.Service;

import com.example.ProductInventoryManagement.Model.Order;
import com.example.ProductInventoryManagement.dto.OrderRequest;
import com.example.ProductInventoryManagement.dto.OrderResponse;

import java.util.List;

public interface OrderService {
    Order createOrder(OrderRequest orderRequest, Long productId, Long buyerId);

   List<Order> getAllOrders();
}
